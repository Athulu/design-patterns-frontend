import java.util.ArrayList;

public interface Composite {
    void display();
}

