public class Main {
    public static void main(String[] args) {
        CompositeNode root = new CompositeNode("Root");

        CompositeNode compositeNode1 = new CompositeNode("Composite Node 1");
        compositeNode1.add(new Leaf("Leaf 1"));
        compositeNode1.add(new Leaf("Leaf 2"));

        CompositeNode compositeNode2 = new CompositeNode("Composite Node 2");
        compositeNode2.add(new Leaf("Leaf 3"));
        compositeNode2.add(new Leaf("Leaf 4"));


        root.add(compositeNode1);
        root.add(compositeNode2);

        root.display();
    }
}
