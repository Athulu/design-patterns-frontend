import java.util.ArrayList;

public class CompositeNode implements Composite {
    private String name;
    private ArrayList<Composite> components;

    //TODO: Stworzenie konstruktora przyjmującego jeden argument name, ustawiającego pole z klasy, oraz inicjujący listę komponentów

    //TODO: funckja add() dodawania componentów do listy

    //TODO: funckja remove() usuwania componentów z listy

    public void display() {
        System.out.println("Composite Node " + name);

        for (Composite component : components) {
            component.display();
        }
    }

    public ArrayList<Composite> getComponents() {
        return components;
    }
}
