//klasa testowa nie edytować
public class Test {
    public static void main(String[] args) {
        CompositeNode root = new CompositeNode("Root");

        CompositeNode compositeNode1 = new CompositeNode("Composite Node 1");
        compositeNode1.add(new Leaf("Leaf 1"));
        compositeNode1.add(new Leaf("Leaf 2"));

        CompositeNode compositeNode2 = new CompositeNode("Composite Node 2");
        compositeNode2.add(new Leaf("Leaf 3"));
        Leaf leaf = new Leaf("Leaf 4");
        compositeNode2.add(leaf);
        compositeNode2.remove(leaf);

        root.add(compositeNode1);
        root.add(compositeNode2);


        int arg = Integer.parseInt(args[0]);
//        int arg = 3;

        if(arg==1){
            if(new CompositeNode("test") instanceof Composite) System.out.println("CompositeNode dziedziczy po klasie Composite");
            else System.out.println("CompositeNode dziedziczy po klasie Composite");
        }else if(arg==2){
            if(new Leaf("test") instanceof Composite) System.out.println("Leaf dziedziczy po klasie Composite");
            else System.out.println("Leaf nie dziedziczy po klasie Composite");
        }else if(arg==3){
            if(root.getComponents().size() == 2) System.out.println("funkcja add() dziala poprawnie");
            else System.out.println("klasa CompositeNode - blad w funkcji add()");
        }else if(arg==4){
            if(compositeNode2.getComponents().size() == 1) System.out.println("funkcja remove() dziala poprawnie");
            else System.out.println("klasa CompositeNode - blad w funkcji remove()");
        }
    }
}
