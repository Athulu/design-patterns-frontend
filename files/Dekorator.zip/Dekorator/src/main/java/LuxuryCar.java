public class LuxuryCar {
    //TODO: konstruktor oraz nadpisanie metody, więcej wskazówek w treści zadania
}