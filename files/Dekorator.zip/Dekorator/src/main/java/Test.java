// Klasa testowa, nie edytować
public class Test {
    public static void main(String[] args) {
        Car sportsCar = new SportsCar(new BasicCar());
        Car luxuryCar = new LuxuryCar(new BasicCar());
        Car sportsLuxuryCar = new SportsCar(new LuxuryCar(new BasicCar()));
        Car mixedCar = new SportsCar(new LuxuryCar(new SportsCar(new LuxuryCar(new BasicCar()))));


        int arg = Integer.parseInt(args[0]);
        if(arg==1){
            String wynik = sportsCar.assemble();
            if(wynik.equals("Car Sport")) System.out.println(wynik);
            else System.out.println("Utworzenie SportsCar zwraca niepoprawny wynik");
        }else if(arg==2){
            String wynik = luxuryCar.assemble();
            if(wynik.equals("Car Luxury")) System.out.println(wynik);
            else System.out.println("Utworzenie LuxuryCar zwraca niepoprawny wynik");
        }else if(arg==3){
            String wynik = sportsLuxuryCar.assemble();
            if(wynik.equals("Car Luxury Sport") || wynik.equals("Car Sport Luxury")) System.out.println(wynik);
            else System.out.println("Utworzenie SportsCar, który jest również LuxuryCar zwraca niepoprawny wynik");
        }else if(arg==4){
            if(sportsCar instanceof CarDecorator) System.out.println("SportsCar dziedziczy po CarDecorator");
            else System.out.println("SportsCar nie dziedziczy po CarDecorator");
        }else if(arg==5){
            if(luxuryCar instanceof CarDecorator) System.out.println("LuxuryCar dziedziczy po CarDecorator");
            else System.out.println("LuxuryCar nie dziedziczy po CarDecorator");
        }else if(arg==6){
            String wynik = mixedCar.assemble();
            if(wynik.equals("Car Luxury Sport Luxury Sport")) System.out.println(wynik);
            else System.out.println("Nie można dekorować wielokrotnie tym samym składnikiem");
        }
    }
}
