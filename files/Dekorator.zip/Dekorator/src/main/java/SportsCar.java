public class SportsCar {
    //TODO: konstruktor oraz nadpisanie metody, więcej wskazówek w treści zadania
}