public interface Car {

    public String assemble();
}