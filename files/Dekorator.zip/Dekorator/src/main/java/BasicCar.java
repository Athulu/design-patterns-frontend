public class BasicCar implements Car {

    @Override
    public String assemble() {
        return "Car";
    }

}