public interface Checkbox {
    String paint();
}