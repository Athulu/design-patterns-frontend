//Nie edytować tej klasy
public class Test {
    public static void main(String[] args) {
        Application app;
        GUIFactory factory;
        int arg = Integer.parseInt(args[0]);
        String osName = "";
        if(arg%2 == 1){
            osName = "windows";
        }else if(arg%2 == 0){
            osName = "mac";
        }
        if (osName.equals("mac")) {
            factory = new MacOSFactory();
        }else if(osName.equals("windows")){
            factory = new WindowsFactory();
        }else{
            factory = null;
        }
        app = new Application(factory);
        if(arg==1){
            String wynik = app.paint();
            if(wynik.equals("WindowsButton WindowsCheckbox")) System.out.println(wynik);
            else System.out.println("WindowsButton lub WindowsCheckbox źle zaimplementowane");
        }else if(arg==2){
            String wynik = app.paint();
            if(wynik.equals("MacOSButton MacOSCheckbox")) System.out.println(wynik);
            else System.out.println("MacOSButton lub MacOSCheckbox źle zaimplementowane");
        }else if(arg==3){
            if(factory instanceof GUIFactory) System.out.println("WindowsFactory implementuje GUIFactory");
            else System.out.println("WindowsFactory nie implementuje GUIFactory");
        }else if(arg==4){
            if(factory instanceof GUIFactory) System.out.println("MacOSFactory implementuje GUIFactory");
            else System.out.println("MacOS nie implementuje GUIFactory");
        }else if(arg==5){
            if(factory.createButton() instanceof Button) System.out.println("WindowsButton implementuje Button");
            else System.out.println("WindowsButton nie implementuje Button");
        }else if(arg==6){
            if(factory.createButton() instanceof Button) System.out.println("MacOSButton implementuje Button");
            else System.out.println("MacOSButton nie implementuje Button");
        }else if(arg==7){
            if(factory.createCheckbox() instanceof Checkbox) System.out.println("WindowsCheckbox implementuje Checkbox");
            else System.out.println("WindowsCheckbox nie implementuje Checkbox");
        }else if(arg==8){
            if(factory.createCheckbox() instanceof Checkbox) System.out.println("MacOSCheckbox implementuje Checkbox");
            else System.out.println("MacOSCheckbox nie implementuje Checkbox");
        }
    }
}
