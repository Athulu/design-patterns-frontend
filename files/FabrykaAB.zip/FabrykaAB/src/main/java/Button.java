public interface Button {
    String paint();
}