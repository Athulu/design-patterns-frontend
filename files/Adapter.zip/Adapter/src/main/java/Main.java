public class Main {

    public static void main(String args[]) {
        Fighter knight = new Knight();
        Wizard wizard = new Wizard();
        WizardAdapter wizardAdapter = new WizardAdapter(wizard);

        System.out.println("#Rycerz");
        System.out.println(knight.attack());
        System.out.println(knight.defend());

        System.out.println("\n#Czarodziej");
        System.out.println(wizardAdapter.attack());
        System.out.println(wizardAdapter.defend());
    }
}