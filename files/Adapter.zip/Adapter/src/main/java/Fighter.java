public interface Fighter {
    public String attack();
    public String defend();
}