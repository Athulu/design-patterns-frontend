public class Wizard {

    public String castDestructionSpell() {
        return "Wizard fireballs";
    }

    public String shield() {
        return "Wizard shields";
    }
}