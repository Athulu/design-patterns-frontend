public class Knight implements Fighter {

    @Override
    public String attack() {
        return "Knight attacks";
    }

    @Override
    public String defend() {
        return "Knight defends";
    }
}