//Klasa testowa, nie edytować

public class Test {

    public static void main(String args[]) {
        int arg = Integer.parseInt(args[0]);

        Wizard wizard = new Wizard();
        WizardAdapter wizardAdapter = new WizardAdapter(wizard);

        if(arg==1){
            String wynik = wizardAdapter.attack();
            if(wynik.equals("Wizard fireballs")) System.out.println(wynik);
            else System.out.println("Metoda attack() w WizardAdapter zwraca niepoprawną wartość");
        }else if(arg==2){
            String wynik = wizardAdapter.defend();
            if(wynik.equals("Wizard shields")) System.out.println(wynik);
            else System.out.println("Metoda defend() w WizardAdapter zwraca niepoprawną wartość");
        }else if(arg==3){
            if(wizardAdapter instanceof Fighter) System.out.println("WizardAdapter implementuje interfejs Figher");
            else System.out.println("WizardAdapter nie implementuje interfejsu Figher");
        }
    }
}