import java.util.ArrayList;
import java.util.List;

public class Logger {
    private static Logger instance = null;
    private List<String> logMessages;

    // Nie ruszaj nic tutaj w konstruktorze
    private Logger() {
        logMessages = new ArrayList<>();
    }

    //TODO: Metoda statyczna zwracająca instację obiektu Logger. Uruchom konstruktor prywatny jeśli zmienna instance wynosi null
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    //TODO: Metoda logMessage() przyjmująca jako argument String, do dodawania logów do listy
    public void logMessage(String message) {
        //uzupełnij
    }

    //TODO: Metoda getLogMessages() zwracająca List<String> (listę logów)
    public List<String> getLogMessages() {
        //uzupełnij
        return null;
    }
}