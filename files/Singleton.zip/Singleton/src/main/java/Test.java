//Nie zmieniać zawartości klasy testowej, na podstawie tego testowany jest program
//Do własnych testów proszę utworzyc osobną klasę wywołującą metodę main
public class Test {
    public static void main(String[] args) {
        int numerTestu = Integer.parseInt(args[0]);

        Logger logger = Logger.getInstance();
        Logger isTheSame = Logger.getInstance();

        if(numerTestu==1){
            if(logger==isTheSame) {
                System.out.println("Ta sama instancja obiektu");
            }else{
                System.out.println("Singleton niepoprawnie zaimplementowany - tworza sie 2 instancje tej klasy");
            }
        }else if(numerTestu==2){
            logger.logMessage("mam psa");
            isTheSame.logMessage("mam kota");

            if(logger.getLogMessages().size()==2){
                System.out.println("Dodano z tego samego loggera");
            } else{
                System.out.println("Logi nie dodają się lub dodaja do roznych obiektow");
            }
        }
    }
}
