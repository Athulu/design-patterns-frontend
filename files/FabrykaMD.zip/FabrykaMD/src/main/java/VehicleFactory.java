import java.util.Scanner;

public class VehicleFactory {

//     Fabryka metoda wytwórcza, nie zmieniaj stringów przyjmowanych w case'ach, ani kolejności tworzenia obiektów
    public static Vehicle getVehicle(String type) {
        switch (type) {
            case "1":
                return new Car();
            case "2":
                return new Motorcycle();
            case "3":
                return new Airplane();
            default:
                return null;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n1. Samochód\n2. Motor\n3. Samolot\n\nWybierz typ pojazdu: ");
        String type = scanner.nextLine();
        Vehicle vehicle = VehicleFactory.getVehicle(type);
        if (vehicle != null) {
            System.out.println(vehicle.startEngine());
        } else {
            System.out.println("Niepoprawny typ pojazdu");
        }
    }
}






