//klasa testowa, nie edytować
public class Test {

    public static Vehicle getVehicle(String type) {
        switch (type) {
            case "1":
                return new Car();
            case "2":
                return new Motorcycle();
            case "3":
                return new Airplane();
            default:
                return null;
        }
    }

    public static void main(String[] args) {
        int sprawdzenie = Integer.parseInt(args[0]);
        int argument = Integer.parseInt(args[0]);
        if(argument <=3){
            Vehicle vehicle = VehicleFactory.getVehicle(String.valueOf(argument));
            if(sprawdzenie==1 && vehicle instanceof Vehicle){
                System.out.println(vehicle.getClass());
            }else if(sprawdzenie==2 && vehicle instanceof Vehicle){
                System.out.println(vehicle.getClass());
            }else if(sprawdzenie==3 && vehicle instanceof Vehicle){
                System.out.println(vehicle.getClass());
            }
        }else{
            Vehicle vehicle = VehicleFactory.getVehicle(String.valueOf(argument-3));
            if(sprawdzenie==4 && vehicle.startEngine()!=null){
                System.out.println("engine car ok");
            }else if(sprawdzenie==5 && vehicle.startEngine()!=null){
                System.out.println("engine motorcycle ok");
            }else if(sprawdzenie==6 && vehicle.startEngine()!=null){
                System.out.println("engine airplane ok");
            }
        }
    }
}
