//klasa testowa, nie edytować
public class Test {

    public static Vehicle getVehicle(String type) {
        switch (type) {
            case "1":
                return new Car();
            case "2":
                return new Motorcycle();
            case "3":
                return new Airplane();
            default:
                return null;
        }
    }

    public static void main(String[] args) {
        int sprawdzenie = Integer.parseInt(args[0]);
        int argument = Integer.parseInt(args[0]);

        if(argument <=3){
            Vehicle vehicle = VehicleFactory.getVehicle(String.valueOf(argument));
            if(sprawdzenie==1){
                if(vehicle instanceof Vehicle){
                    System.out.println(vehicle.getClass());
                }else{
                    System.out.println("Car nie jest implementacją klasy Vehicle");
                }
            }else if(sprawdzenie==2){
                if(vehicle instanceof Vehicle){
                    System.out.println(vehicle.getClass());
                }else{
                    System.out.println("Motorcycle nie jest implementacją klasy Vehicle");
                }
            }else if(sprawdzenie==3){
                if(vehicle instanceof Vehicle){
                    System.out.println(vehicle.getClass());
                }else{
                    System.out.println("Airplane nie jest implementacją klasy Vehicle");
                }
            }
        }else{
            Vehicle vehicle = VehicleFactory.getVehicle(String.valueOf(argument-3));
            if(sprawdzenie==4){
                if(vehicle instanceof Vehicle){
                    System.out.println("engine car ok");
                }else{
                    System.out.println("wywołanie metody engine w klasie Car zwraca zły wynik");
                }
            }else if(sprawdzenie==5){
                if(vehicle instanceof Vehicle){
                    System.out.println("engine motorcycle ok");
                }else{
                    System.out.println("wywołanie metody engine w klasie Car zwraca zły wynik");
                }
            }else if(sprawdzenie==6){
                if(vehicle.startEngine()!=null){
                    System.out.println("engine airplane ok");
                }else{
                    System.out.println("wywołanie metody engine w klasie Car zwraca zły wynik");
                }
            }
        }
    }
}
