import system.Circle;
import system.Rectangle;
import system.Shape;
import system.Square;

//Klasa testowa, nie edytować
public class Test {
    public static void main(String[] args) {
        ShapeMaker shapeMaker = new ShapeMaker();
        int arg = Integer.parseInt(args[0]);
//        int arg = 9;

        if(arg==1){
            if(shapeMaker.drawCircle().equals("system.Circle")) System.out.println(shapeMaker.drawCircle());
            else System.out.println("nie zwraca słowa system.Circle");
        }else if(arg==2){
            if(shapeMaker.drawRectangle().equals("system.Rectangle")) System.out.println(shapeMaker.drawRectangle());
            else System.out.println("nie zwraca słowa system.Rectangle");
        }else if(arg==3){
            if(shapeMaker.drawSquare().equals("system.Square")) System.out.println(shapeMaker.drawSquare());
            else System.out.println("nie zwraca słowa system.Square");
        }else if(arg==4){
            if(shapeMaker.getCircle() instanceof Circle) System.out.println("zmienna circle jest typu system.Circle");
            else System.out.println("zmienna circle nie jest typu system.Circle");
        }else if(arg==5){
            if(shapeMaker.getRectangle() instanceof Rectangle) System.out.println("zmienna rectangle jest typu system.Rectangle");
            else System.out.println("zmienna rectangle nie jest typu system.Rectangle");
        }else if(arg==6){
            if(shapeMaker.getSquare() instanceof Square) System.out.println("zmienna square jest typu system.Square");
            else System.out.println("zmienna square nie jest typu system.Square");
        }else if(arg==7){
            if(new Circle() instanceof Shape) System.out.println("Klasa system.Circle implementuje interfejs system.Shape");
            else System.out.println("Klasa system.Circle nie implementuje interfejsu system.Shape");
        }else if(arg==8){
            if(new Rectangle() instanceof Shape) System.out.println("Klasa system.Rectangle implementuje interfejs system.Shape");
            else System.out.println("Klasa system.Rectangle nie implementuje interfejsu system.Shape");
        }else if(arg==9){
            if(new Square() instanceof Shape) System.out.println("Klasa system.Square implementuje interfejs system.Shape");
            else System.out.println("Klasa system.Square nie implementuje interfejsu system.Shape");
        }
    }
}
