public class Main {
    public static void main(String[] args) {
        ShapeMaker shapeMaker = new ShapeMaker();

        System.out.println(shapeMaker.drawCircle());
        System.out.println(shapeMaker.drawRectangle());
        System.out.println(shapeMaker.drawSquare());
    }
}
