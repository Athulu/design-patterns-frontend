public class ShapeMaker {
    private Shape circle;
    private Shape rectangle;
    private Shape square;

    public ShapeMaker() {
        circle = new Circle();
        rectangle = new Rectangle();
        square = new Square();
    }

    //odkomentować i wywołać na obiektach przypisancyh do zmiennych, odpowiednią funkcję i ją zwrócić
//    public String drawCircle(){
//
//    }
//    public String drawRectangle(){
//
//    }
//    public String drawSquare(){
//
//    }

    //nie ruszać getterów
    public Shape getCircle() {
        return circle;
    }

    public Shape getRectangle() {
        return rectangle;
    }

    public Shape getSquare() {
        return square;
    }
}