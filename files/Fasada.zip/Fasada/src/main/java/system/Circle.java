package system;

public class Circle implements Shape {

    @Override
    public String draw() {
        return "system.Circle";
    }
}