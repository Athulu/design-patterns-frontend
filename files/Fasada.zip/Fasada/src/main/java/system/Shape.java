package system;

public interface Shape {
    String draw();
}