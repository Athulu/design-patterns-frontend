public class updateObserver extends Observer {

    public updateObserver(Subject subject){
        //TODO: przypisz do zmiennej subject (która jest dziedzioczna z klasy abstrakcyjnej Observer) argument przekazany do konstruktora
        // -a w następnej instrukcji przypisz na zmiennej tego obiektu utworzony obserwator za pomocą funkcji attach()
        // aby przekazać ten obserwator wystarczy do funkcji attach() wrzucić słowo kluczowe "this", odnoszące się do tego obserwatora
    }

    @Override
    public void update() {
        System.out.println("state updated");
    }
}
