public class Subject {

    private Observer observer;
    private int state;

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
        //TODO: wowołaj tutaj po prostu funkcję notifyObserver()
    }

    public void attach(Observer observer){
        //TODO: Przypisz przekazany obserwator do tego zmiennej w tej klasie
    }

    public void notifyObserver(){
        //TODO: wywołaj na zmiennej obserwatora funkcję update()
    }
}