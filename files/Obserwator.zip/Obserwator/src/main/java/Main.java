import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Subject subject = new Subject();
        new updateObserver(subject);

        Scanner scanner = new Scanner(System.in);
        while(true){
            subject.setState(scanner.nextInt());
        }
    }
}