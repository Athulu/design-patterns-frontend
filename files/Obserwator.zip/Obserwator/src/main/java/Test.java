import java.util.Scanner;

public class Test {

    public static void main(String[] args) {

        Subject subject = new Subject();
        Observer obserwator = new updateObserver(subject);

        int arg = Integer.parseInt(args[0]);
        if(arg==1){
            if(obserwator instanceof Observer) System.out.println("updateObserver dzidziczy po Observer");
            else System.out.println("updateObserver nie dzidziczy po Observer");
        }else if(arg==2){
            if(subject== obserwator.subject) System.out.println("Poprawnie przekazany obiekt klasy Subject");
            else System.out.println("Niepoprawnie przekazany obiekt typu Subject w konstruktorze obserwatora");
        }else if(arg==3){
            subject.setState(10);
        }
    }
}
