// Klasa testowa, nie edytować
public class Test {
    public static void main(String[] args) {
        Context context1 = new Context(new OperationAdd());
        Context context2 = new Context(new OperationSubstract());
        Context context3 = new Context(new OperationMultiply());

        int arg = Integer.parseInt(args[0]);
        if(arg==1){
            if(context1.executeStrategy(10, 5)==15) System.out.println("Context klasy OperationAdd dziala poprawnie");
            else System.out.println("Context OperationAdd() zwraca niepoprawny wynik");
        }else if(arg==2){
            if(context2.executeStrategy(10, 5)==5) System.out.println("Context klasy OperationSubstract dziala poprawnie");
            else System.out.println("Context OperationAdd() zwraca niepoprawny wynik");
        }else if(arg==3){
            if(context3.executeStrategy(10, 5)==50) System.out.println("Context klasy OperationMultiply dziala poprawnie");
            else System.out.println("Context OperationAdd() zwraca niepoprawny wynik");
        }else if(arg==4){
            if(new OperationAdd() instanceof Strategy) System.out.println("OperationAdd implementuje interfejs Strategy");
            else System.out.println("OperationAdd nie implementuje interfejsu Strategy");
        }else if(arg==5){
            if(new OperationSubstract() instanceof Strategy) System.out.println("OperationSubstract implementuje interfejs Strategy");
            else System.out.println("OperationSubstract nie implementuje interfejsu Strategy");
        }else if(arg==6){
            if(new OperationMultiply() instanceof Strategy) System.out.println("OperationMultiply implementuje interfejs Strategy");
            else System.out.println("OperationMultiply nie implementuje interfejsu Strategy");
        }

    }
}
