public class Context {
    private Strategy strategy;

    public Context(Strategy strategy){
        //TODO: Przypisz strategię z argumentu to zmiennej tej klasy
    }

    public int executeStrategy(int num1, int num2){
        //TODO: metoda ma wywołać na obiekcie ze zmiennej strategy, metodę doOperation, przekazując jej swoje argumenty
    }
}