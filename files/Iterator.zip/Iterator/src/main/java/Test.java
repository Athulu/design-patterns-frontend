// Klasa testowa, nie edytować

public class Test {
    public static void main(String[] args) {
        NameRepository namesRepository = new NameRepository();

        String ciag = "";
        for(Iterator iter = namesRepository.getIterator(); iter.hasNext();){
            String name = (String) iter.next();
            ciag += name;
        }

        int arg = Integer.parseInt(args[0]);
        if(arg==1){
            if(namesRepository instanceof Container) System.out.println("NamesRepository implementuje interfejs Container");
            else System.out.println("namesRepository nie implementuje interfejsu Container");
        }else if(arg==2){
            if(namesRepository.getIterator() instanceof Iterator) System.out.println("NewIterator implementuje interfejs Iterator");
            else System.out.println("NewIterator nie implementuje interfejsu Iterator");
        }else if(arg==3){
            if(ciag.equals("MikolajNikodemAdrianArtur")) System.out.println(ciag);
            else System.out.println("Iterator nie iteruje kolejno po wszystkich elementach tablicy");
        }
    }
}
