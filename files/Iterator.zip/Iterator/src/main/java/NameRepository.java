public class NameRepository implements Container {
    public String names[] = {"Mikolaj", "Nikodem", "Adrian", "Artur"};

    //TODO: zaimplementuj funkcję getIterator()

    //powinien iterować po elementach w tej kolejności w jakiej są wpisane do tablicy names[]
    private class NewIterator implements Iterator {
        int index;

        //TODO: zaimplementuj metodę hasNext()

        //TODO: zaimplementuj metodę next(), jeśli istnieje kolejny element ma zwrócić ten element inkrementując później zmienną index
        // w przypadku kiedy nie istnieje kolejny element, zwrócić nulla
    }
}
