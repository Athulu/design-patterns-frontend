public interface Container {
    Iterator getIterator();
}